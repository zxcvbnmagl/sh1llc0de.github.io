<?php

if($_GET['action'] == 'get_prompt'){
    echo '本pass禁止上传.asp|.aspx|.php|.jsp后缀文件！';
}

?>