<?php
header("Content-type: text/html;charset=utf-8");
//error_reporting(0);

//设置靶机所在路径
$site_root = "/upload-labs";

//设置上传目录
$UPLOAD_ADDR = "../upload/";

?>